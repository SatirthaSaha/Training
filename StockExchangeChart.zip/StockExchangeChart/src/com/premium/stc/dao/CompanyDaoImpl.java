package com.premium.stc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.premium.stc.model.Company;

public class CompanyDaoImpl implements CompanyDao{

	public Company insertCompany(Company company) throws SQLException  {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("insert into company (clo) values(?,?,?,?,?)");
		ps.setInt(1, company.getCompanyId());
		ps.executeUpdate();
		return company;
		
	}

	@Override
	public Company updateCompany(Company company) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("update table company (clo) values(?,?,?,?,?)");
		ps.setInt(1, company.getCompanyId());
		ps.executeUpdate();
		return company;
		
	}
	
	public static void main(String []args) throws Exception{
		CompanyDao dao=new CompanyDaoImpl(); 
		Company compnay=new Company();
		 /* compnay.setCompanyId(1001);
		 */
		//dao.insertCompany(compnay);
		System.out.println(dao.getCompanyList());
	}
	
	public List<Company> getCompanyList() throws SQLException{
		System.out.println("inside list dao");
		List <Company> companyList=new ArrayList<Company>();
		try {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/satirtha","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from company");
		ResultSet rs=	ps.executeQuery();
		
		Company company=null;
		while(rs.next()){
			 company=new Company();
			 int companyId=rs.getInt("company_code");
			company.setCompanyId(companyId);
			company.setBoardOfDirectors(rs.getString("boardofdirectors"));
			companyList.add(company);
		}
		}catch(SQLException e)
		{
			System.out.println(e);
			throw e;
		}
		return companyList;
	}

	
	

}