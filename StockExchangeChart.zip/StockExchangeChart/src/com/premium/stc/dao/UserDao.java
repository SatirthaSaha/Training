package com.premium.stc.dao;

import com.premium.stc.model.Login;
import com.premium.stc.model.User;

public interface UserDao {

	public boolean loginUser(Login login);
	public boolean registerUser(User user);
	public boolean updateUser(User user);
	
}
