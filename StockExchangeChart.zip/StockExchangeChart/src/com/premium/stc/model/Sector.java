package com.premium.stc.model;

public class Sector {

}
